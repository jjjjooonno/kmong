dt_gongsi<- read.csv('ptprices.csv')
dt_tranc<- read.csv('pyungteak.csv')
library(ggplot2)
ggplot(dt_gongsi,aes(year,price))+geom_col()

ggplot(dt_tranc,aes(date,price))+geom_col()

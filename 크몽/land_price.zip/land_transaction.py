from pandas import DataFrame
from bs4 import BeautifulSoup
import urllib.request
import json
import xml.etree.ElementTree
from xml.etree.ElementTree import parse
import xml.etree.ElementTree as ET

years = ['2013','2014','2015','2016','2017']
months = ['01','02','03','04','05','06','07','08','09','10','11','12']
date_list = []
mean_price = []
for year in years:
    for month in months:
        date = year+month
        url = 'http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcLandTrade?&type=json&serviceKey=XGjk3lw3HWVPQUnt%2FbK0ps7Oun48a%2FVgEb0n1PnbqqERTRXj2wwdybeabsJBVinRb2braJKLp9y0jGc8RpQAdw%3D%3D&LAWD_CD=41220&DEAL_YMD={0}'.format(date)
        p = urllib.request.urlopen(url)
        soup = BeautifulSoup(p,'lxml')
        prices = []
        for i in soup.find_all('item'):
            group = str(i).split('&gt;')
            print(group)
            price = group[0][6:-4].replace(",", "")
            pyung = group[1][:-4].replace(",", "")
            prices.append(int(price)/int(pyung))
        meanprice = sum(prices)/len(prices)*1000
        date_list.append(year+'/'+month)
        mean_price.append(meanprice)
dt = DataFrame({'date' : date_list,'price' : mean_price})
dt.to_csv('pyungteak.csv')